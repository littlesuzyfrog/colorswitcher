// link for coolers palette
// https://coolors.co/89043d-2fe6de-1c3041
// change background color to claret
document.getElementById("button1").onclick=function() {
    document.getElementById("screen").style.background="#89043D"
}

// change background color to turquoise
document.getElementById("button2").onclick=function() {
    document.getElementById("screen").style.background="#2FE6DE"
}

// change background color to gunmetal

document.getElementById("button3").onclick=function() {
    document.getElementById("screen").style.background="#1C3041"
}

// change background color to white
document.getElementById("button4").onclick=function() {
    document.getElementById("screen").style.background="white"
}
